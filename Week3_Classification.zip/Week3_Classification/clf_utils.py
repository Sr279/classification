"""Helper functions for the Week 3 classification project (tested in tests/test_clf_utils.py)."""
import numpy as np
import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

RANDOM_STATE = 42


def load_data():
    """Breast Cancer Wisconsin (Diagnostic) data from scikit-learn.
    Returns X (569 x 30 DataFrame) and y (Series): 1 = malignant (the case we must not miss), 0 = benign."""
    bunch = load_breast_cancer(as_frame=True)
    y = (bunch.target == 0).astype(int).rename("malignant")   # scikit-learn codes malignant as 0, so we flip it
    return bunch.data.copy(), y


def make_split(X, y, test_size=0.2, seed=RANDOM_STATE):
    """Stratified train/test split (keeps the same share of malignant cases in both parts)."""
    if not 0 < test_size < 1:
        raise ValueError("test_size must be between 0 and 1")
    if len(X) != len(y):
        raise ValueError("X and y must have the same number of rows")
    return train_test_split(X, y, test_size=test_size, stratify=y, random_state=seed)


def build_models():
    """The three models of the project: a baseline and the two classifiers (default settings)."""
    return {
        "Baseline (always benign)": DummyClassifier(strategy="most_frequent"),
        # the scaler is INSIDE the pipeline, so it is fitted on training data only (no leakage)
        "Logistic Regression": make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000, random_state=RANDOM_STATE)),
        "Random Forest": RandomForestClassifier(n_estimators=300, random_state=RANDOM_STATE),
    }


def compute_metrics(y_true, y_pred, y_score=None):
    """Accuracy, precision, recall, F1 (and ROC-AUC if scores are given) for labels 0/1 (1 = positive class)."""
    y_true, y_pred = np.asarray(y_true), np.asarray(y_pred)
    if len(y_true) == 0:
        raise ValueError("y_true is empty")
    if len(y_true) != len(y_pred):
        raise ValueError("y_true and y_pred must have the same length")
    if not (set(np.unique(y_true)) <= {0, 1} and set(np.unique(y_pred)) <= {0, 1}):
        raise ValueError("labels must be 0 or 1")
    result = {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
    }
    if y_score is not None:
        if len(np.unique(y_true)) < 2:
            raise ValueError("ROC-AUC needs both classes in y_true")
        result["roc_auc"] = roc_auc_score(y_true, y_score)
    return result
