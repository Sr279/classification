"""Tests: each test checks ONE thing and has a clear name; normal cases and failure cases."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

import numpy as np
import pytest
from clf_utils import load_data, make_split, build_models, compute_metrics

X, y = load_data()
X_train, X_test, y_train, y_test = make_split(X, y)


# ---------- data ----------
def test_data_has_569_rows_and_30_features():
    assert X.shape == (569, 30)

def test_data_has_212_malignant_cases_coded_as_1():
    assert int(y.sum()) == 212

def test_data_has_no_missing_values():
    assert int(X.isna().sum().sum()) == 0


# ---------- split ----------
def test_split_sizes_are_455_train_and_114_test():
    assert (len(X_train), len(X_test)) == (455, 114)

def test_train_and_test_do_not_share_any_row():
    assert set(X_train.index).isdisjoint(set(X_test.index))

def test_split_keeps_malignant_share_within_one_percent():
    assert abs(y_train.mean() - y_test.mean()) < 0.01

def test_split_with_test_size_above_one_raises_valueerror():
    with pytest.raises(ValueError):
        make_split(X, y, test_size=1.5)

def test_split_with_different_lengths_raises_valueerror():
    with pytest.raises(ValueError):
        make_split(X, y.iloc[:-1])


# ---------- metrics ----------
def test_perfect_predictions_give_accuracy_1():
    assert compute_metrics([1, 0, 1, 0], [1, 0, 1, 0])["accuracy"] == pytest.approx(1.0)

def test_known_example_gives_precision_1():
    assert compute_metrics([1, 1, 0, 0], [1, 0, 0, 0])["precision"] == pytest.approx(1.0)

def test_known_example_gives_recall_one_half():
    assert compute_metrics([1, 1, 0, 0], [1, 0, 0, 0])["recall"] == pytest.approx(0.5)

def test_known_example_gives_f1_two_thirds():
    assert compute_metrics([1, 1, 0, 0], [1, 0, 0, 0])["f1"] == pytest.approx(2 / 3)

def test_roc_auc_of_perfectly_ranked_scores_is_1():
    assert compute_metrics([0, 0, 1, 1], [0, 0, 1, 1], [0.1, 0.2, 0.8, 0.9])["roc_auc"] == pytest.approx(1.0)

def test_metrics_with_different_lengths_raise_valueerror():
    with pytest.raises(ValueError):
        compute_metrics([1, 0, 1], [1, 0])

def test_metrics_with_empty_input_raise_valueerror():
    with pytest.raises(ValueError):
        compute_metrics([], [])

def test_metrics_with_labels_other_than_0_and_1_raise_valueerror():
    with pytest.raises(ValueError):
        compute_metrics([1, 2, 0], [1, 0, 0])

def test_roc_auc_with_only_one_class_raises_valueerror():
    with pytest.raises(ValueError):
        compute_metrics([1, 1, 1], [1, 1, 1], [0.9, 0.8, 0.7])


# ---------- models ----------
def test_three_models_are_defined_baseline_and_two_classifiers():
    assert list(build_models()) == ["Baseline (always benign)", "Logistic Regression", "Random Forest"]

def test_baseline_never_finds_a_malignant_case():
    base = build_models()["Baseline (always benign)"].fit(X_train, y_train)
    assert compute_metrics(y_test, base.predict(X_test))["recall"] == 0

def _f1_scores():
    return {n: compute_metrics(y_test, m.fit(X_train, y_train).predict(X_test))["f1"] for n, m in build_models().items()}

def test_logistic_regression_beats_baseline_f1():
    f1 = _f1_scores()
    assert f1["Logistic Regression"] > f1["Baseline (always benign)"]

def test_random_forest_beats_baseline_f1():
    f1 = _f1_scores()
    assert f1["Random Forest"] > f1["Baseline (always benign)"]

def test_scaler_in_pipeline_learns_mean_from_training_data_only():
    pipe = build_models()["Logistic Regression"].fit(X_train, y_train)
    assert np.allclose(pipe[0].mean_, X_train.mean().to_numpy())
