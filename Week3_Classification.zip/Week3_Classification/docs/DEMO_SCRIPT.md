# Demo video script (under 5 minutes, main flow only)

| Time | What to show | What to say (own words) |
|---|---|---|
| 0:00-0:30 | README / notebook title | "My Week 3 project: I train two classifiers on the Breast Cancer Wisconsin data and compare them with proper metrics." |
| 0:30-1:00 | Step 1 + Chart 1 | "569 patients, 30 measurements, no missing values. 37% are malignant. Malignant is the positive class." |
| 1:00-1:30 | Step 2 (split) | "I split into train and test first and lock the test set until the end." |
| 1:30-2:15 | Step 3 baseline + cross-validation table | "A baseline that always says benign gets 63% accuracy but recall 0. That is why accuracy is not enough." |
| 2:15-3:00 | Step 4-5: tuning and test-set table, Charts 3 and 4 | "Logistic Regression and Random Forest both beat the baseline. Both miss 3 malignant patients; Random Forest has no false alarms." |
| 3:00-3:40 | Step 6 bootstrap + Step 7 threshold table | "The F1 difference is within luck, so I choose Logistic Regression using cross-validation, not the test set. Lowering the threshold finds more malignant cases but gives more false alarms." |
| 3:40-4:30 | Terminal: `pytest -v` (22 passed); sanity checks cell | "I tested the split, the metrics and the no-leakage rule." |
| 4:30-5:00 | Close | "I learned ... Thank you." |

Practise once. Explain the idea, do not read every number.
