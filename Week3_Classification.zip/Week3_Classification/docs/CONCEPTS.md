# Classification Concepts (plain words + worked example)

## The confusion matrix
Predictions compared with the truth. "Positive" = the class we care about (here: malignant).

| | Predicted positive | Predicted negative |
|---|---|---|
| **Actually positive** | TP (true positive: found) | FN (false negative: **missed**) |
| **Actually negative** | FP (false positive: false alarm) | TN (true negative: correctly cleared) |

## Metrics
| Metric | Formula | Question it answers |
|---|---|---|
| Accuracy | (TP + TN) / all | How often is the model right overall? (misleading when classes are unequal) |
| Precision | TP / (TP + FP) | When the model says "positive", how often is it right? |
| Recall (sensitivity) | TP / (TP + FN) | Of all real positives, how many did it find? |
| F1 score | 2 x precision x recall / (precision + recall) | One number balancing precision and recall |
| ROC-AUC | area under the ROC curve | How well does it rank positives above negatives? (0.5 = guessing, 1 = perfect) |

### Worked example (100 patients: 45 malignant, 55 benign)
The model finds 40 of the 45 malignant tumours (TP = 40, FN = 5) and wrongly flags 10 of the 55 benign ones (FP = 10, TN = 45).

- Accuracy = (40 + 45) / 100 = **0.85**
- Precision = 40 / (40 + 10) = **0.80**
- Recall = 40 / (40 + 5) = **0.889**
- F1 = 2 x 0.80 x 0.889 / (0.80 + 0.889) = **0.842**

A baseline that always says "benign" has accuracy 55/100 = 0.55 but recall 0.

## Other ideas used in this project
| Idea | Meaning |
|---|---|
| Train / test split | Train on one part, judge on a part the model has never seen |
| Stratified | Both parts keep the same class proportions |
| Baseline | A very simple model; real models must beat it |
| Cross-validation | Split the training data into k parts, validate on each in turn; gives a mean and a spread |
| Overfitting | The model memorises the training data and does worse on new data |
| Data leakage | Information from the test data sneaks into training (for example fitting a scaler on all the data) |
| Hyperparameter tuning | Trying model settings (for example C, tree depth) with cross-validation on the training set |
| Threshold | Probability above which we predict "positive" (default 0.5) |
| Bootstrap | Resample the test set many times to see how much a metric can change by luck |

## Logistic Regression vs Random Forest
| | Logistic Regression | Random Forest |
|---|---|---|
| Idea | weighted sum of features turned into a probability | many decision trees vote |
| Needs scaling? | yes (we use StandardScaler in a pipeline) | no |
| Interpretable? | coefficients show direction | feature importances show relevance |
| Speed / size | very fast and small | slower, bigger |
| Good when | relationships are roughly linear, you need to explain | relationships are complex or non-linear |

## Common mistakes
- Judging the model on the data it was trained on.
- Fitting the scaler on all the data before splitting (leakage).
- Reporting accuracy only.
- Choosing the model because it looks best on the test set, then reporting the same test set as proof.
- Forgetting which class is "positive" (here malignant = 1).
