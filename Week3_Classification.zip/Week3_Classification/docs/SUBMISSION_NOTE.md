# Short note for the portal (edit in your own words)

**What I built:** A classification project on the Breast Cancer Wisconsin (Diagnostic) dataset (569 patients, 30 features). I split the data into train and test first, built a baseline (always "benign"), then trained two classifiers - Logistic Regression and Random Forest - with a scaler inside a pipeline to avoid leakage. I compared them with 5-fold cross-validation, tuned them with grid search on the training set only, and judged them once on the test set with accuracy, precision, recall, F1, ROC-AUC, confusion matrices and ROC/precision-recall curves. I added a bootstrap check of the difference between the models and a threshold analysis. 22 pytest tests and 7 sanity checks pass. A written model report (PDF) explains the choice.

**What I learned:** (write 2-3 lines yourself: for example why a baseline with 63% accuracy still has recall 0, what a confusion matrix shows, why I picked the model with cross-validation and not by looking at the test set.)

**Files:** `Week3_Classification.ipynb`, `reports/Model_Report.pdf`, `clf_utils.py`, `tests/`, charts, README, demo video link.
