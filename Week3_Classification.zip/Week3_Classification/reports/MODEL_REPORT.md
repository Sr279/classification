# Model Report — Classifying Tumours as Malignant or Benign

**Goal (one sentence):** train two classifiers on the Breast Cancer Wisconsin (Diagnostic) data, compare them with proper metrics, and explain which one to prefer and why.

> Educational project only. It is not a medical tool and must not be used to diagnose anyone.

## 1. Problem and why the metric matters
A tumour is **malignant** (positive class, 1) or **benign** (0). A *missed malignant tumour* (false negative) is much worse than a *false alarm* (false positive), so we pay special attention to **recall** (the share of malignant cases found) and balance it with **precision** (the share of alarms that are real). Accuracy alone is misleading: a model that always says "benign" is 63.2% accurate but finds **no** malignant case.

## 2. Data
- **Source:** Breast Cancer Wisconsin (Diagnostic), a real dataset bundled with scikit-learn (originally from the UCI repository).
- 569 patients, 30 numeric measurements of cell nuclei (radius, texture, concavity ...), no missing values.
- Classes: 357 benign (62.7%), 212 malignant (37.3%) — moderately unbalanced.
- Note: scikit-learn codes malignant as 0; this project flips it so that **1 = malignant** is the positive class.

![Chart 1](../images/01_class_balance.png)
*Chart 1 — Is the data balanced? Somewhat: about 63% benign and 37% malignant.*

![Chart 2](../images/02_feature_separation.png)
*Chart 2 — Which measurements separate the classes? The "worst" (largest) values of concave points, perimeter and radius differ most between malignant and benign tumours.*

## 3. Method (what was done, in order)
1. **Stratified split first:** 80% train (455 patients), 20% test (114 patients, 42 malignant), `random_state = 42`. The test set was not touched until the final step.
2. **Baseline:** a dummy model that always predicts "benign".
3. **Two classifiers:** Logistic Regression (features standardised inside a pipeline, so the scaler learns from training data only) and Random Forest (300 trees).
4. **5-fold stratified cross-validation** on the training set to compare models with a mean and a spread.
5. **Tuning** with grid search on the training set (optimising F1): Logistic Regression `{'logisticregression__C': 1}`; Random Forest `{'max_depth': 5, 'min_samples_leaf': 1, 'n_estimators': 100}`.
6. **Model selection using cross-validation only:** Logistic Regression had the higher cross-validation F1.
7. **One final evaluation on the test set** with accuracy, precision, recall, F1, ROC-AUC and confusion matrices, plus a bootstrap interval for the difference between the models.

## 4. Results

### 4.1 Cross-validation on the training set (mean of 5 folds, after tuning)
| Model | accuracy | precision | recall | f1 | roc_auc |
|---|---|---|---|---|---|
| Baseline (always benign) | 0.626 | 0.000 | 0.000 | 0.000 | 0.500 |
| Logistic Regression | 0.974 | 0.977 | 0.953 | 0.964 | 0.996 |
| Random Forest | 0.967 | 0.964 | 0.947 | 0.955 | 0.988 |

Standard deviation across folds is about 0.02-0.04 for the real models, so differences of 0.01 between them are within the noise.

### 4.2 Test set (114 patients, 42 malignant) — used once
| Model | accuracy | precision | recall | f1 | roc_auc | average_precision |
|---|---|---|---|---|---|---|
| Baseline (always benign) | 0.632 | 0.000 | 0.000 | 0.000 | 0.500 | 0.368 |
| Logistic Regression | 0.965 | 0.975 | 0.929 | 0.951 | 0.996 | 0.994 |
| Random Forest | 0.974 | 1.000 | 0.929 | 0.963 | 0.995 | 0.992 |

![Chart 3](../images/03_metrics_comparison.png)
*Chart 3 — Which model is better on each metric? Both classifiers are far above the baseline, whose recall is 0.*

### 4.3 Mistakes (confusion matrices)
| Model | Malignant found (TP) | Malignant **missed** (FN) | Benign flagged (FP) | Benign cleared (TN) |
|---|---|---|---|---|
| Logistic Regression | 39 | 3 | 1 | 71 |
| Random Forest | 39 | 3 | 0 | 72 |

![Chart 4](../images/04_confusion_matrices.png)
*Chart 4 — What kinds of mistakes does each model make? Both miss 3 of the 42 malignant patients; the difference is in false alarms (1 vs 0).*

![Chart 5](../images/05_roc_pr_curves.png)
*Chart 5 — How well do the models rank patients by risk? Both curves hug the top-left corner (ROC-AUC 0.996 and 0.995); the baseline is the diagonal.*

### 4.4 Is the difference real?
On the test set Random Forest has the higher F1 (difference Random Forest − Logistic Regression = +0.012). The 95% bootstrap interval is **(-0.042, +0.072)**, which contains 0: the difference could easily be luck, because one patient changes a metric by about 1 percentage point.

### 4.5 Precision vs recall: the threshold (Logistic Regression, out-of-fold on the training set)
| Threshold | Precision | Recall | F1 | Missed malignant | False alarms |
|---|---|---|---|---|---|
| 0.1 | 0.862 | 0.988 | 0.921 | 2 | 27 |
| 0.2 | 0.923 | 0.982 | 0.952 | 3 | 14 |
| 0.3 | 0.954 | 0.976 | 0.965 | 4 | 8 |
| 0.4 | 0.965 | 0.965 | 0.965 | 6 | 6 |
| 0.5 | 0.976 | 0.953 | 0.964 | 8 | 4 |
| 0.6 | 0.981 | 0.935 | 0.958 | 11 | 3 |
| 0.7 | 1.000 | 0.924 | 0.960 | 13 | 0 |

Lowering the threshold finds more malignant cases (higher recall) but creates more false alarms. If missing a cancer is considered much worse than a false alarm, a threshold below 0.5 is worth discussing with the domain expert.

### 4.6 What the models use
![Chart 6](../images/06_feature_importance.png)
*Chart 6 — Which measurements drive the predictions? Random Forest relies most on the "worst" area, concave points, radius and perimeter. Many features are strongly correlated (radius, perimeter, area), so importance is shared between them and the Logistic Regression coefficients should not be read one by one.*

## 5. Conclusion
- **Both classifiers clearly beat the baseline** (F1 0.95 and 0.96 vs 0.00) with ROC-AUC about 0.99.
- **Selected model: Logistic Regression**, chosen with cross-validation before looking at the test set. It is simple, fast and easy to explain. Random Forest is equally usable: on the test set the two models are statistically indistinguishable (section 4.4), and both miss 3 malignant patients.
- We did **not** switch models because Random Forest looked slightly better on the test set; that would be using the test set for model selection.
- Recall (about 0.93) is the weak point for both models; the threshold analysis shows how to trade false alarms for fewer missed cases.

## 6. Limitations and next steps
- Small test set (114 patients): results can change by a few points with another split. Repeated cross-validation or a larger dataset would give firmer numbers.
- One dataset from one source: no external validation, so the results may not hold for other hospitals or devices.
- Probabilities were not calibrated; a medical use would need calibration, clinical validation and regulatory approval.
- More models (gradient boosting, SVM), feature selection and cost-sensitive learning could be tried.

## 7. Reproducibility
`python classification.py` (or run `Week3_Classification.ipynb`) recreates every number and chart; `random_state = 42` everywhere. Tests: `pytest -v` (22 tests).
