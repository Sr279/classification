# Week 3 — Classification: Train 2 Classifiers and Compare with Proper Metrics

**Task (compulsory):** Train 2 classifiers and compare using proper metrics.

**What I hand in (one sentence):** a notebook that splits the data first, builds a baseline, trains two classifiers (Logistic Regression and Random Forest) and compares them with precision, recall, F1, ROC-AUC, confusion matrices and cross-validation, plus a written model report.

## Start here
1. Read **`reports/Model_Report.pdf`** (7 pages: report + concepts). Same text in `reports/MODEL_REPORT.md` and `docs/CONCEPTS.md`.
2. Run **`Week3_Classification.ipynb`** (outputs are already included, but run it yourself once).
3. Run the tests: `pytest -v` -> 22 passed.

## How this follows the portal tips
| Tip | Where |
|---|---|
| Always split data into train and test before judging a model | Step 2 (stratified 80/20); the test set is used once, in Step 5 |
| Start with a simple baseline, then improve it | Step 3 baseline (always "benign"), then default models, then tuning in Step 4 |

## Results (test set, 114 patients, 42 malignant)
| Model | Accuracy | Precision | Recall | F1 | ROC-AUC |
|---|---|---|---|---|---|
| Baseline (always benign) | 0.632 | 0.000 | 0.000 | 0.000 | 0.500 |
| Logistic Regression | 0.965 | 0.975 | 0.929 | 0.951 | 0.996 |
| Random Forest | 0.974 | 1.000 | 0.929 | 0.963 | 0.995 |

- Both classifiers miss 3 of 42 malignant patients; false alarms: Logistic Regression 1, Random Forest 0.
- The difference between the two models is within what luck can produce (bootstrap interval contains 0), so the model was chosen with **cross-validation** (Logistic Regression), not by peeking at the test set.
- The baseline has 0.632 accuracy but recall 0: this is why accuracy alone is not a proper metric.

## Folder
```
Week3_Classification/
  README.md
  requirements.txt
  Week3_Classification.ipynb    <- main work (outputs included, 6 charts)
  classification.py             <- the same code as one script
  clf_utils.py                  <- load data, split, models, metrics (tested)
  tests/test_clf_utils.py       <- 22 pytest tests
  data/breast_cancer_wisconsin.csv   <- copy of the data (30 features + diagnosis)
  images/                       <- 6 charts
  models/                       <- saved models (.joblib)
  reports/
    Model_Report.pdf            <- report + concepts (7 pages)
    MODEL_REPORT.md
    test_results.csv, cv_results.csv
  docs/CONCEPTS.md, DEMO_SCRIPT.md, SUBMISSION_NOTE.md
```

## Setup (virtual environment)
```
python -m venv .venv
# Windows:      .venv\Scripts\activate
# macOS/Linux:  source .venv/bin/activate
pip install -r requirements.txt
pytest -v                       # 22 passed
jupyter notebook                # open Week3_Classification.ipynb, Run All
python classification.py        # or run everything as a script
```
**Google Colab:** upload the notebook and `clf_utils.py`, then Runtime -> Run all (scikit-learn is already installed).

## The dataset
Breast Cancer Wisconsin (Diagnostic) is a **real** dataset that comes with scikit-learn (originally UCI). Remember: scikit-learn codes malignant as 0; this project flips it so that **1 = malignant** is the positive class.
**This is an educational project, not a medical tool.**

## Submission checklist
- [ ] Virtual environment created, `pytest -v` shows 22 passed
- [ ] Notebook runs top to bottom ("All 7 sanity checks passed" at the end)
- [ ] Read the report and understand: baseline, split, cross-validation, confusion matrix, recall vs precision
- [ ] Write "What I learned" (notebook and `docs/SUBMISSION_NOTE.md`) in your own words
- [ ] Record the demo video (under 5 minutes, `docs/DEMO_SCRIPT.md`)
- [ ] Upload in My Submissions and check the status
