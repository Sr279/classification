"""Week 3 - Classification: runs the whole project. Run:  python classification.py"""
import matplotlib
matplotlib.use("Agg")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import joblib
from pathlib import Path
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score, classification_report, confusion_matrix,
                             f1_score, precision_recall_curve, roc_curve)
from sklearn.model_selection import GridSearchCV, StratifiedKFold, cross_val_predict, cross_validate
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from clf_utils import RANDOM_STATE, build_models, compute_metrics, load_data, make_split

pd.set_option("display.width", 120)
pd.set_option("display.max_columns", 30)
for folder in ["data", "images", "reports", "models"]:
    Path(folder).mkdir(exist_ok=True)
plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False, "font.size": 10})
COLORS = {"Baseline (always benign)": "#999999", "Logistic Regression": "#2a6fdb", "Random Forest": "#2A9D8F"}

X, y = load_data()
df = X.copy()
df["diagnosis"] = y.map({1: "malignant", 0: "benign"})
df.to_csv("data/breast_cancer_wisconsin.csv", index=False)
print("Shape (rows, features):", X.shape)
print("Missing values:", int(X.isna().sum().sum()))
print()
print(df["diagnosis"].value_counts())
print(f"\nMalignant share: {100 * y.mean():.1f}%")
print()
print(df.iloc[:5, [0, 1, 2, 3, 4, -1]])

counts = df["diagnosis"].value_counts()
fig, ax = plt.subplots(figsize=(5, 3.5))
bars = ax.bar(counts.index, counts.values, color=["#2A9D8F", "#E76F51"])
ax.bar_label(bars, labels=[f"{v} ({100 * v / len(df):.0f}%)" for v in counts.values], padding=2)
ax.set_title("Chart 1: Cases per class")
ax.set_ylabel("Number of patients")
plt.tight_layout()
plt.savefig("images/01_class_balance.png", dpi=120)
plt.close()

gap = ((X[y == 1].mean() - X[y == 0].mean()) / X.std()).abs().sort_values(ascending=False)
top4 = list(gap.index[:4])
print("Features with the biggest gap between the classes (in standard deviations):")
print(gap.head(4).round(2))
fig, axes = plt.subplots(2, 2, figsize=(9, 6))
for ax, col in zip(axes.ravel(), top4):
    ax.hist(X.loc[y == 0, col], bins=25, alpha=0.65, color="#2A9D8F", label="benign")
    ax.hist(X.loc[y == 1, col], bins=25, alpha=0.65, color="#E76F51", label="malignant")
    ax.set_title(col)
axes[0, 0].legend()
fig.suptitle("Chart 2: The four most separating features")
plt.tight_layout()
plt.savefig("images/02_feature_separation.png", dpi=120)
plt.close()

X_train, X_test, y_train, y_test = make_split(X, y)          # 80% train / 20% test, random_state = 42
print(f"Train: {len(X_train)} rows | malignant share {100 * y_train.mean():.1f}%")
print(f"Test : {len(X_test)} rows | malignant share {100 * y_test.mean():.1f}%")
assert set(X_train.index).isdisjoint(X_test.index)

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
scoring = ["accuracy", "precision", "recall", "f1", "roc_auc"]
default_models = build_models()
cv_means, cv_stds = {}, {}
for name, model in default_models.items():
    res = cross_validate(model, X_train, y_train, cv=cv, scoring=scoring)
    cv_means[name] = {s: res["test_" + s].mean() for s in scoring}
    cv_stds[name] = {s: res["test_" + s].std() for s in scoring}
cv_default = pd.DataFrame(cv_means).T
print("Cross-validation on the training set (mean of 5 folds):")
print(cv_default.round(3))
print("\nStandard deviation across folds:")
print(pd.DataFrame(cv_stds).T.round(3))

grid_lr = GridSearchCV(
    make_pipeline(StandardScaler(), LogisticRegression(max_iter=5000, random_state=RANDOM_STATE)),
    {"logisticregression__C": [0.01, 0.1, 1, 10, 100]}, cv=cv, scoring="f1")
grid_rf = GridSearchCV(
    RandomForestClassifier(random_state=RANDOM_STATE),
    {"n_estimators": [100, 300], "max_depth": [None, 5, 10], "min_samples_leaf": [1, 3]}, cv=cv, scoring="f1")
grid_lr.fit(X_train, y_train)
grid_rf.fit(X_train, y_train)

tuning = pd.DataFrame({
    "default CV F1": [cv_default.loc["Logistic Regression", "f1"], cv_default.loc["Random Forest", "f1"]],
    "tuned CV F1": [grid_lr.best_score_, grid_rf.best_score_],
    "best settings": [str(grid_lr.best_params_), str(grid_rf.best_params_)],
}, index=["Logistic Regression", "Random Forest"])
print(tuning.to_string())

cv_tuned = {}
for name, grid in [("Logistic Regression", grid_lr), ("Random Forest", grid_rf)]:
    res = cross_validate(grid.best_estimator_, X_train, y_train, cv=cv, scoring=scoring)
    cv_tuned[name] = {s: res["test_" + s].mean() for s in scoring}
cv_tuned = pd.DataFrame(cv_tuned).T
print("Tuned models - cross-validation on the training set:")
print(cv_tuned.round(3))
selected = cv_tuned["f1"].idxmax()
print(f"\nSelected by cross-validation F1 (test set not used yet): {selected}")

dummy = default_models["Baseline (always benign)"].fit(X_train, y_train)
final_models = {"Baseline (always benign)": dummy,
                "Logistic Regression": grid_lr.best_estimator_,
                "Random Forest": grid_rf.best_estimator_}
rows, preds, scores = {}, {}, {}
for name, model in final_models.items():
    preds[name] = model.predict(X_test)
    scores[name] = model.predict_proba(X_test)[:, 1]
    rows[name] = compute_metrics(y_test, preds[name], scores[name])
    rows[name]["average_precision"] = average_precision_score(y_test, scores[name])
test_table = pd.DataFrame(rows).T
print("Test-set results:")
print(test_table.round(3))

cms = {}
for name in ["Logistic Regression", "Random Forest"]:
    tn, fp, fn, tp = confusion_matrix(y_test, preds[name]).ravel()
    cms[name] = dict(tn=int(tn), fp=int(fp), fn=int(fn), tp=int(tp))
    print(f"--- {name} ---")
    print(f"True positives (malignant found)     : {tp}")
    print(f"False negatives (malignant MISSED)   : {fn}")
    print(f"False positives (benign flagged)     : {fp}")
    print(f"True negatives (benign cleared)      : {tn}")
    print(classification_report(y_test, preds[name], target_names=["benign", "malignant"], digits=3))

metrics_to_plot = ["accuracy", "precision", "recall", "f1", "roc_auc"]
fig, ax = plt.subplots(figsize=(10, 4))
width = 0.26
for i, name in enumerate(final_models):
    vals = test_table.loc[name, metrics_to_plot].astype(float).values
    bars = ax.bar(np.arange(len(metrics_to_plot)) + (i - 1) * width, vals, width, label=name, color=COLORS[name])
    ax.bar_label(bars, labels=[f"{v:.2f}" for v in vals], fontsize=7, padding=1)
ax.set_xticks(np.arange(len(metrics_to_plot)))
ax.set_xticklabels(["Accuracy", "Precision", "Recall", "F1", "ROC-AUC"])
ax.set_ylim(0, 1.12)
ax.set_title("Chart 3: Test-set metrics (the baseline has recall 0)")
ax.legend(loc="lower right", fontsize=8)
plt.tight_layout()
plt.savefig("images/03_metrics_comparison.png", dpi=120)
plt.close()

fig, axes = plt.subplots(1, 2, figsize=(9, 4))
for ax, name in zip(axes, ["Logistic Regression", "Random Forest"]):
    c = cms[name]
    grid = np.array([[c["tn"], c["fp"]], [c["fn"], c["tp"]]])
    ax.imshow(grid, cmap="Blues")
    for (r, k), v in np.ndenumerate(grid):
        ax.text(k, r, str(v), ha="center", va="center", fontsize=16, color="white" if v > grid.max() / 2 else "black")
    ax.set_xticks([0, 1]); ax.set_xticklabels(["pred. benign", "pred. malignant"])
    ax.set_yticks([0, 1]); ax.set_yticklabels(["actual benign", "actual malignant"])
    ax.set_title(f"{name}\nmissed malignant: {c['fn']} | false alarms: {c['fp']}", fontsize=10)
fig.suptitle("Chart 4: Confusion matrices on the test set")
plt.tight_layout()
plt.savefig("images/04_confusion_matrices.png", dpi=120)
plt.close()

fig, axes = plt.subplots(1, 2, figsize=(10, 4))
for name in final_models:
    fpr, tpr, _ = roc_curve(y_test, scores[name])
    axes[0].plot(fpr, tpr, label=f"{name} (AUC {test_table.loc[name, 'roc_auc']:.3f})", color=COLORS[name])
    prec, rec, _ = precision_recall_curve(y_test, scores[name])
    axes[1].plot(rec, prec, label=name, color=COLORS[name])
axes[0].plot([0, 1], [0, 1], ":", color="#bbbbbb")
axes[0].set_xlabel("False positive rate"); axes[0].set_ylabel("True positive rate (recall)"); axes[0].set_title("ROC curve")
axes[0].legend(fontsize=8, loc="lower right")
axes[1].set_xlabel("Recall"); axes[1].set_ylabel("Precision"); axes[1].set_title("Precision-recall curve")
axes[1].set_ylim(0, 1.05)
fig.suptitle("Chart 5: Ranking quality on the test set")
plt.tight_layout()
plt.savefig("images/05_roc_pr_curves.png", dpi=120)
plt.close()

rng = np.random.default_rng(RANDOM_STATE)
yt = y_test.to_numpy()
p_lr, p_rf = preds["Logistic Regression"], preds["Random Forest"]
diffs = []
for _ in range(2000):
    idx = rng.integers(0, len(yt), len(yt))
    diffs.append(f1_score(yt[idx], p_rf[idx]) - f1_score(yt[idx], p_lr[idx]))
boot_ci = np.percentile(diffs, [2.5, 97.5])
observed_diff = f1_score(yt, p_rf) - f1_score(yt, p_lr)
print(f"F1 difference (Random Forest - Logistic Regression) on the test set: {observed_diff:+.3f}")
print(f"95% bootstrap interval: ({boot_ci[0]:+.3f}, {boot_ci[1]:+.3f})")
print("The interval contains 0 -> the difference could be luck." if boot_ci[0] <= 0 <= boot_ci[1]
      else "The interval does not contain 0 -> the difference is unlikely to be luck.")

oof = cross_val_predict(final_models[selected], X_train, y_train, cv=cv, method="predict_proba")[:, 1]
rows = []
for thr in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7]:
    pred_thr = (oof >= thr).astype(int)
    m = compute_metrics(y_train, pred_thr)
    rows.append({"threshold": thr, "precision": m["precision"], "recall": m["recall"], "f1": m["f1"],
                 "missed malignant": int(((pred_thr == 0) & (y_train.to_numpy() == 1)).sum()),
                 "false alarms": int(((pred_thr == 1) & (y_train.to_numpy() == 0)).sum())})
threshold_table = pd.DataFrame(rows).set_index("threshold")
print(f"Selected model: {selected} (out-of-fold predictions on {len(y_train)} training patients)")
print(threshold_table.round(3))

lr_coef = pd.Series(grid_lr.best_estimator_[-1].coef_[0], index=X.columns)
rf_imp = pd.Series(grid_rf.best_estimator_.feature_importances_, index=X.columns)
top_lr = lr_coef.reindex(lr_coef.abs().sort_values(ascending=False).index).head(10)
top_rf = rf_imp.sort_values(ascending=False).head(10)
print("Random Forest - top 5 importances:")
print(top_rf.head(5).round(3))
print("\nLogistic Regression - top 5 coefficients (positive = pushes towards malignant):")
print(top_lr.head(5).round(2))

fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
t = top_rf.iloc[::-1]
axes[0].barh(t.index, t.values, color="#2A9D8F")
axes[0].set_title("Random Forest: importance")
t = top_lr.iloc[::-1]
axes[1].barh(t.index, t.values, color=["#E76F51" if v > 0 else "#2a6fdb" for v in t.values])
axes[1].set_title("Logistic Regression: coefficient (red = towards malignant)")
for ax in axes:
    ax.tick_params(axis="y", labelsize=8)
fig.suptitle("Chart 6: Top 10 features of each model")
plt.tight_layout()
plt.savefig("images/06_feature_importance.png", dpi=120)
plt.close()

joblib.dump(grid_lr.best_estimator_, "models/logistic_regression.joblib")
joblib.dump(grid_rf.best_estimator_, "models/random_forest.joblib")
test_table.round(4).to_csv("reports/test_results.csv")
pd.concat({"default": cv_default, "tuned": cv_tuned}).round(4).to_csv("reports/cv_results.csv")

reloaded = joblib.load("models/random_forest.joblib")
sample = X_test.iloc[:5]
print("Saved models reloaded. Predictions for 5 test patients (1 = malignant):", reloaded.predict(sample).tolist())
print("Actual labels                                           :", y_test.iloc[:5].tolist())

assert set(X_train.index).isdisjoint(X_test.index), "train and test overlap"
assert abs(y_train.mean() - y_test.mean()) < 0.01, "split is not stratified"
assert np.allclose(grid_lr.best_estimator_[0].mean_, X_train.mean().to_numpy()), "scaler saw test data"
assert test_table.loc["Baseline (always benign)", "recall"] == 0, "baseline should miss every malignant case"
for name in ["Logistic Regression", "Random Forest"]:
    assert test_table.loc[name, "f1"] > test_table.loc["Baseline (always benign)", "f1"], name + " does not beat the baseline"
assert ((test_table.astype(float) >= 0) & (test_table.astype(float) <= 1)).all().all(), "metric outside 0-1"
assert (reloaded.predict(X_test) == preds["Random Forest"]).all(), "saved model gives different predictions"
print("All 7 sanity checks passed")
